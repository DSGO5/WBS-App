package edu.curtin.app;

public class WBSException extends Exception
{
    public WBSException(String message) //Constructor
    {
        super(message);
    }
}
