package edu.curtin.app;
import java.util.List; 

public interface Option 
{ //Interface for the options
    void doOption(List<Integer> list, WBSItem task); 
}